// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This command is to go to the Page Learn and its Sub Menu --
 Cypress.Commands.add('goToLearn', subMenu => {
    cy.wait(4000)
    cy.get('.nav-opener').click() 
    cy.wait(2000) 
    cy.get('#menu-item-8117').click({force: true})    
    cy.contains(subMenu).click()
    cy.wait(2000) 
 })

 // -- This command is to Browse for Categories --
 Cypress.Commands.add('searchBlog', searchFor => {
    cy.get('.custom-forms > [type="search"]').type(searchFor)
    cy.wait(2000)   
 })

 // -- This command is to Browse for Categories --
 Cypress.Commands.add('browseCategories', category => {
    cy.get('.jcf-select-text').click()
    cy.wait(1000)
    cy.get('.jcf-list-content > ul > li').each(ele => {
             if (ele.text() == category) {
                cy.wrap(ele).click();
            }
       });
       cy.wait(3000)
 })

//  Cypress.Commands.add('loadAvailableBlogs', () => {
//      do{
//         cy.get('.btn-load-holder > .btn').click()
//         cy.wait(2000)
//      }while(cy.get('.btn-load-holder > .btn') != null)
//  })
 
// function loadMoreArticle () {
//     cy
//       .request('')
//       .then((resp) => { 
//         if (resp.status === 200 && resp.body.ok === true)
//           // break out of the recursive loop
//           recy
//           cy.get('.btn-load-holder > .btn').click()
//           .then(req)
//           req()        
//       })
// } 
  
//  it('load more Article', function () {
//     cy.wait('.btn-load-holder > .btn')
//     .its('response.body')
//     .then(JSON.parse) // convert string to array
//     .then((fruits) => {
//       cy.get('.favorite-fruits li').should('have.length', fruits.length)  
//       fruits.forEach((fruit) => {
//         cy.contains('.favorite-fruits li', fruit)
//       })

//       cy.request('https://jsonplaceholder.cypress.io/comments').as('comments')
//         cy.get('@comments').should((response) => {
//         expect(response.body).to.have.length(500)
//         expect(response).to.have.property('headers')
//         expect(response).to.have.property('duration')
//         })
//     })
//    })

 // -- This command is to select option from View by Type dropdown
 Cypress.Commands.add('viewByType', option => {
     cy.get('.filter-resource').find('.drop-opener').contains('View by Type').scrollIntoView().click({force: true})
     cy.wait(2000)
     cy.get('.type-filter').find('label > .fake-label').contains(option).click()   
     cy.get('.filter-resource').find('.drop-opener').contains('View by Type').click({force: true})
 })

 // -- This command is to select option from View by Process dropdown
 Cypress.Commands.add('viewByProcess', option => {
    cy.get('.filter-resource').find('.drop-opener').contains('View by Process').click({force: true})
    cy.wait(2000)
    cy.get('.process-filter').find('label > .fake-label').contains(option).click() 
    cy.get('.filter-resource').find('.drop-opener').contains('View by Process').click({force: true})
    cy.wait(3000)
})
