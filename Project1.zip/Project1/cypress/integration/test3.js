/// <reference types= "cypress" />

it('launch GAN Integrity portal', () => {
    cy.visit('/') 
}) 

it ('Search for resources by Type and by Process', function() {
    cy.goToLearn('Resource Center')
    cy.url().should('include', '/resources')
    cy.viewByType('eBook')
    cy.viewByProcess('Policy Deployment')
})

it('Verify Resources abd Banners', function(){
    cy.get('.resources-posts').find('.text-holder').should('have.length', 3)
    cy.get('.resources-posts').find('.banner-post').should('have.length', 1)
})