/// <reference types="cypress" />


it('launch GAN Integrity portal', () => {
     cy.visit('/') 
}) 

it ('Verify Browse Categories', function() {
    cy.goToLearn('The Connected CCO Blog')
    cy.url().should('include', '/blog')
    cy.searchBlog('UK Bribery Act Enforcement')
    // cy.loadAvailableBlogs()
    // const total = 0
    // cy.get('.posts-holder > article').find('ul').find('a[href*="blog/category/legislation/"]').each ((ele, list) => {        
    //     expect(ele).to.have.text('Latest in Legislation')
    // }).then((list) => {
    //     total = list.length
    //     cy.log("Total count:" + total)
    // })
    cy.browseCategories('Latest in Legislation')
})

it('Verify Articles', function() {    
    cy.get('.posts-holder > article').find('ul').find('a[href*="blog/category/legislation/"]').each ((ele, list) => {        
        expect(ele).to.have.text('Latest in Legislation')
    }).then((list) => {
        expect(list).to.have.length(6)
    })
})