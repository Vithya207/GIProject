/// <reference types ="cypress" />

it('launch GAN Integrity portal', () => {
    cy.visit('/blog') 
}) 

it ('Reset Browse Categories', function() {
    cy.searchBlog('Assessment Process')
    cy.browseCategories('GAN Updates')
    cy.get('.reset > .fas').click()
    cy.wait(2000)
    cy.get('.custom-forms > [type="search"]').should('have.attr', 'placeholder', 'Search...')
    cy.get('.jcf-select-text > span').should('contain', 'Browse categories')
})